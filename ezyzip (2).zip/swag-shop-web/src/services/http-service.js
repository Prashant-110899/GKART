import 'whatwg-fetch';
// import 'express';
//
// // const app = express();
// // const cors = require('cors');
// // app.use(cors());

class httpService{
  getProducts = () => {
    var promise = new Promise((resolve, reject) => {
      fetch('http://localhost:3008/product')
      .then(response =>{
        resolve(response.json());
      })
    });

    return promise;
    // return new Promise((resolve, reject) => {
    //   setTimeout(() => {
    //     fetch('http://localhost:3008/product')
    //     .then(response => {
    //       console.log(response.json());
    //     });
    //
    //     const error = false;
    //
    //     if(!error){
    //       resolve();
    //     }else {
    //       reject('Error: Something went wrong!');
    //     }
    //   },10000);
    // });
  }
}


export default httpService;
